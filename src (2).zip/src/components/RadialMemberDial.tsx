import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Users } from "lucide-react";

interface Member {
  id: string;
}

interface RadialMemberDialProps {
  sortedMembers: Member[];
  maxMemberNumber: number;
  openMember: (memberId: string) => void;
  handleActiveGroupChange: (groupStart: number | null) => void;
  selectMode: boolean;
}

interface Group {
  start: number;
  end: number;
  label: string;
}

interface WheelItem {
  label: string;
  value: number | string;
}

const WHEEL_RADIUS = 130;
const DEAD_ZONE_RADIUS = 40;
const HOLD_DELAY = 550;

export function RadialMemberDial({
  sortedMembers,
  maxMemberNumber,
  openMember,
  handleActiveGroupChange,
  selectMode,
}: RadialMemberDialProps) {
  const [stage, setStage] = useState<
    "idle" | "group-wheel" | "group-locked" | "member-wheel"
  >("idle");
  const [lockedGroup, setLockedGroup] = useState<Group | null>(null);
  const [highlightedIndex, setHighlightedIndex] = useState<number | null>(null);
  const [buttonCenter, setButtonCenter] = useState({ x: 0, y: 0 });
  const [showHint, setShowHint] = useState(() => {
    try {
      return !localStorage.getItem("radial-dial-hint-shown");
    } catch {
      return true;
    }
  });

  const buttonRef = useRef<HTMLButtonElement>(null);
  const holdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const centerRef = useRef({ x: 0, y: 0 });
  const isHoldingRef = useRef(false);

  const groups = useMemo(() => {
    const gs: Group[] = [];
    for (let start = 1; start <= maxMemberNumber; start += 10) {
      const end = Math.min(start + 9, maxMemberNumber);
      gs.push({ start, end, label: `${start}-${end}` });
    }
    return gs;
  }, [maxMemberNumber]);

  const getMembersInGroup = useCallback(
    (group: Group) => {
      return sortedMembers
        .filter((m) => {
          const n = Number(m.id);
          return Number.isFinite(n) && n >= group.start && n <= group.end;
        })
        .map((m) => ({ id: m.id, number: Number(m.id) }))
        .sort((a, b) => a.number - b.number);
    },
    [sortedMembers],
  );

  const dismissHint = useCallback(() => {
    setShowHint(false);
    try {
      localStorage.setItem("radial-dial-hint-shown", "true");
    } catch {}
  }, []);

  const reset = useCallback(() => {
    setStage("idle");
    setLockedGroup(null);
    setHighlightedIndex(null);
    setButtonCenter({ x: 0, y: 0 });
    centerRef.current = { x: 0, y: 0 };
    isHoldingRef.current = false;
  }, []);

  const getCenter = useCallback(() => {
    if (!buttonRef.current) return { x: 0, y: 0 };
    const rect = buttonRef.current.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }, []);

  const getWheelItems = useCallback((): WheelItem[] => {
    if (stage === "group-wheel") {
      return groups.map((g) => ({ label: g.label, value: g.start }));
    }
    if (stage === "member-wheel" && lockedGroup) {
      return getMembersInGroup(lockedGroup).map((m) => ({
        label: m.id,
        value: m.number,
      }));
    }
    return [];
  }, [stage, groups, lockedGroup, getMembersInGroup]);

  const handlePointerDown = useCallback(
    (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      const btn = buttonRef.current;
      if (btn) {
        btn.setPointerCapture(e.pointerId);
      }

      const center = getCenter();
      centerRef.current = center;
      setButtonCenter(center);
      isHoldingRef.current = true;

      holdTimerRef.current = setTimeout(() => {
        setStage((prev) => {
          if (prev === "idle") return "group-wheel";
          if (prev === "group-locked") return "member-wheel";
          return prev;
        });
        setHighlightedIndex(null);
      }, HOLD_DELAY);
    },
    [getCenter],
  );

  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLButtonElement>) => {
      if (!isHoldingRef.current) return;
      if (stage !== "group-wheel" && stage !== "member-wheel") return;

      const cx = centerRef.current.x;
      const cy = centerRef.current.y;
      if (cx === 0 && cy === 0) return;

      const dx = e.clientX - cx;
      const dy = e.clientY - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < DEAD_ZONE_RADIUS) {
        setHighlightedIndex(null);
        return;
      }

      const angle =
        (Math.atan2(dy, dx) + Math.PI / 2 + 2 * Math.PI) % (2 * Math.PI);
      const items = getWheelItems();
      const numItems = items.length;
      if (numItems === 0) return;

      const anglePerItem = (2 * Math.PI) / numItems;
      const index = Math.floor(angle / anglePerItem) % numItems;
      setHighlightedIndex(index);
    },
    [stage, getWheelItems],
  );

  const handlePointerUp = useCallback(
    (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();

      if (holdTimerRef.current) {
        clearTimeout(holdTimerRef.current);
        holdTimerRef.current = null;
      }

      isHoldingRef.current = false;

      if (stage === "group-wheel" && highlightedIndex !== null) {
        const group = groups[highlightedIndex];
        if (group) {
          handleActiveGroupChange(group.start);
          setLockedGroup(group);
          setStage("group-locked");
          dismissHint();
        }
      } else if (
        stage === "member-wheel" &&
        lockedGroup &&
        highlightedIndex !== null
      ) {
        const members = getMembersInGroup(lockedGroup);
        const member = members[highlightedIndex];
        if (member) {
          openMember(member.id);
          dismissHint();
          reset();
          return;
        }
      }

      if (stage === "group-wheel" || stage === "member-wheel") {
        setHighlightedIndex(null);
      }
      setButtonCenter({ x: 0, y: 0 });
      centerRef.current = { x: 0, y: 0 };
    },
    [
      stage,
      highlightedIndex,
      groups,
      lockedGroup,
      getMembersInGroup,
      handleActiveGroupChange,
      openMember,
      dismissHint,
      reset,
    ],
  );

  useEffect(() => {
    return () => {
      if (holdTimerRef.current) {
        clearTimeout(holdTimerRef.current);
      }
    };
  }, []);

  const items = getWheelItems();
  const showWheel = stage === "group-wheel" || stage === "member-wheel";
  const hasCenter = buttonCenter.x > 0 && buttonCenter.y > 0;

  const renderWedge = (item: WheelItem, i: number) => {
    const numItems = items.length;
    const anglePerItem = (2 * Math.PI) / numItems;
    const startAngle = i * anglePerItem - Math.PI / 2;
    const endAngle = (i + 1) * anglePerItem - Math.PI / 2;
    const isHighlighted = highlightedIndex === i;

    const x1 = WHEEL_RADIUS + WHEEL_RADIUS * Math.cos(startAngle);
    const y1 = WHEEL_RADIUS + WHEEL_RADIUS * Math.sin(startAngle);
    const x2 = WHEEL_RADIUS + WHEEL_RADIUS * Math.cos(endAngle);
    const y2 = WHEEL_RADIUS + WHEEL_RADIUS * Math.sin(endAngle);
    const largeArc = anglePerItem > Math.PI ? 1 : 0;
    const path = `M ${WHEEL_RADIUS} ${WHEEL_RADIUS} L ${x1} ${y1} A ${WHEEL_RADIUS} ${WHEEL_RADIUS} 0 ${largeArc} 1 ${x2} ${y2} Z`;

    const midAngle = (startAngle + endAngle) / 2;
    const labelRadius = WHEEL_RADIUS * 0.62;
    const lx = WHEEL_RADIUS + labelRadius * Math.cos(midAngle);
    const ly = WHEEL_RADIUS + labelRadius * Math.sin(midAngle);

    return (
      <g key={i}>
        <path
          d={path}
          fill={isHighlighted ? "#2563eb" : "#f1f5f9"}
          stroke="#ffffff"
          strokeWidth={2}
          className={isHighlighted ? "drop-shadow-lg" : "drop-shadow-sm"}
        />
        <text
          x={lx}
          y={ly}
          textAnchor="middle"
          dominantBaseline="central"
          fill={isHighlighted ? "#ffffff" : "#1e293b"}
          fontSize="12"
          fontWeight="700"
          fontFamily="system-ui, sans-serif"
          pointerEvents="none"
        >
          {item.label}
        </text>
      </g>
    );
  };

  return (
    <div
      className={`fixed left-0 right-0 z-50 flex justify-center pointer-events-none transition-all duration-300 ${
        selectMode ? "bottom-24" : "bottom-6"
      } lg:left-[280px]`}
    >
      <div className="relative pointer-events-auto">
        {showHint && stage === "idle" && (
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 z-10">
            <div className="bg-slate-900 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-lg whitespace-nowrap">
              Hold to dial
            </div>
          </div>
        )}

        {stage === "group-locked" && lockedGroup && (
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 z-10 whitespace-nowrap">
            <div className="bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-lg">
              Group {lockedGroup.label} — Hold to pick member
            </div>
          </div>
        )}

        {showWheel && hasCenter && (
          <svg
            className="fixed pointer-events-none"
            style={{
              left: buttonCenter.x - WHEEL_RADIUS,
              top: buttonCenter.y - WHEEL_RADIUS,
              width: WHEEL_RADIUS * 2,
              height: WHEEL_RADIUS * 2,
            }}
          >
            <defs>
              <filter id="wedge-shadow">
                <feDropShadow dx="0" dy="1" stdDeviation="2" floodOpacity="0.15" />
              </filter>
              <filter id="wedge-shadow-lg">
                <feDropShadow dx="0" dy="2" stdDeviation="4" floodOpacity="0.25" />
              </filter>
            </defs>
            {items.map((item, i) => renderWedge(item, i))}
          </svg>
        )}

        <button
          ref={buttonRef}
          type="button"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          style={{ touchAction: "none" }}
          className="w-16 h-16 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-full shadow-lg flex items-center justify-center text-white transition-colors admin-press select-none"
          aria-label={
            stage === "group-locked" && lockedGroup
              ? `Group ${lockedGroup.label} selected. Hold to pick a member.`
              : "Quick Dial - hold to find a member by group"
          }
        >
          {showWheel && highlightedIndex !== null ? (
            <span className="text-[10px] font-black leading-tight text-center">
              {items[highlightedIndex]?.label}
            </span>
          ) : (
            <Users className="w-7 h-7" />
          )}
        </button>

        {stage === "group-locked" && lockedGroup && (
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 z-10">
            <button
              type="button"
              onClick={() => {
                setStage("idle");
                setLockedGroup(null);
              }}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 hover:underline transition-colors bg-white/90 px-2 py-1 rounded shadow-sm"
            >
              Change group
            </button>
          </div>
        )}
      </div>

      <div aria-live="polite" className="sr-only">
        {stage === "group-locked" && lockedGroup
          ? `Group ${lockedGroup.label} selected. Hold again to pick a member.`
          : stage === "group-wheel"
            ? highlightedIndex !== null
              ? `${items[highlightedIndex]?.label} highlighted`
              : "Drag outward to select a group"
            : stage === "member-wheel"
              ? highlightedIndex !== null
                ? `Member ${items[highlightedIndex]?.label} highlighted`
                : "Drag outward to select a member"
              : "Quick dial ready"}
      </div>
    </div>
  );
}
