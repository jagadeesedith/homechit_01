import { Navigate } from 'react-router-dom';

import { useAuth } from '@/hooks/useAuth';

import { AppLayout } from './AppLayout';

import type { ReactNode } from 'react';

interface ProtectedRouteProps {
  children: ReactNode;
}

export function ProtectedRoute({
  children
}: ProtectedRouteProps) {

  const {
    isAuthenticated,
    loading
  } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!isAuthenticated) {

    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  return (
    <AppLayout>
      {children}
    </AppLayout>
  );
}